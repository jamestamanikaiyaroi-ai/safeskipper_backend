# SafeSkipper Backend (Skeleton)

This is a minimal FastAPI backend skeleton for SafeSkipper, suitable for deploying to Render.

## Local run

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

Then open http://127.0.0.1:8000 in your browser.
```